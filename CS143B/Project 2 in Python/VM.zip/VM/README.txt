To run the python program, run it normally either through whatever program you can run it with.
Or run it on the command line/bash.
Run it however you like.

Once you run it, the program will ask for 3 inputs:
	*The init filename
	*The input filename
	*The output filename
	Make sure you include the extension along with the file. (i.e .txt)

Assuming you have the init and input filenames correctly, it should run without issue.
Please contact me though if you have any issues.