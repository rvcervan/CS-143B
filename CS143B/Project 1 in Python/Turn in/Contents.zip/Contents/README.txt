Before running, make sure the input file is named "input.txt" and in the same directory as the python file.

Run the the python file in the command line by navigating to the directory and issuing the command "python Shell.py".

This will run the program and create a file called "output.txt" in the same directory.

You can also run the python code in whatever program editor as well, it should do the same thing.